import React,{Suspense,lazy} from 'react';
import {Routes,Route} from 'react-router-dom';
import Navbar from './components/Navbar'

//utilizando lazy
const Home=lazy (()=>import('./pages/Home'));
const Sobre=lazy (()=>import('./pages/Sobre'));
const Contato=lazy (()=>import('./pages/Contato'));

function App() {
  

  return (
    <>
    <Navbar/>
    <Suspense fallback={<div>Carregando</div>}>
    <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='/sobre' element={<Sobre/>}/>
      <Route path='/contato' element={<Contato/>}/>
    </Routes>

    </Suspense>
      
    </>
  )
}

export default App
