function Home (){
    return( 
        <div>
            <h1>Página Inicial</h1>
            <p>Seja Bem vindo</p>
        </div>
    );
}
export default Home;