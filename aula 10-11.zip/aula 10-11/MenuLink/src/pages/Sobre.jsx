function Sobre (){
    return( 
        <div>
            <h1>Página Sobre</h1>
            <p>Seja Bem vindo</p>
        </div>
    );
}
export default Sobre;