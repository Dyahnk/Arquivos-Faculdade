function Contato (){
    return( 
        <div>
            <h1>Página Contato</h1>
            <p>Seja Bem vindo</p>
        </div>
    );
}
export default Contato;