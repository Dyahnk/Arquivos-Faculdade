import React from 'react';
//importar ReactDOM
import ReactDOM from 'react-dom/client';
//habilitar o roteamento
import {BrowserRouter} from 'react-router-dom';
//componente principal
import App from './App.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <App />
  </BrowserRouter>,
)
