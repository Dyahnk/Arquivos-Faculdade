import './CardProduto.css';

function CardProduto({ imagem, nome, preco, descricao }) {
  return (
    <div className="card-produto">
      <img src={imagem} alt={nome} className="card-imagem" />
      <h2 className="card-nome">{nome}</h2>
      <p className="card-descricao">{descricao}</p>
      <p className="card-preco">R$ {preco}</p>
      <button className="card-botao">Adicionar ao carrinho</button>
    </div>
  );
}

export default CardProduto;