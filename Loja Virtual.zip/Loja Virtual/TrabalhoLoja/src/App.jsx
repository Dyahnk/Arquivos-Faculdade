import './App.css';
import CardProduto from './components/cardproduto/CardProduto';

function App() {
  const produtos = [
    {
      imagem: '/img/geladeira.jpg',
      nome: 'Geladeira Frost Free',
      preco: '2999,90',
      descricao: 'Geladeira moderna com capacidade de 500L e sistema frost free.',
    },
    {
      imagem: '/img/microondas.jpg',
      nome: 'Micro-ondas Inox',
      preco: '799,90',
      descricao: 'Design moderno e potência de 1200W.',
    },
    {
      imagem: '/img/liquidificador.jpg',
      nome: 'Liquidificador Turbo',
      preco: '249,90',
      descricao: 'Alta potência e lâminas de aço inox.',
    },
    {
      imagem: '/img/cafeteira.jpg',
      nome: 'Cafeteira Elétrica',
      preco: '189,90',
      descricao: 'Prepara café fresquinho em minutos.',
    },
    {
      imagem: '/img/aspirador.jpg',
      nome: 'Aspirador de Pó',
      preco: '499,90',
      descricao: 'Potente e leve, ideal para limpeza diária.',
    },
    {
      imagem: '/img/batedeira.jpg',
      nome: 'Batedeira Planetária',
      preco: '699,90',
      descricao: 'Perfeita para massas pesadas e leves.',
    },
  ];

  return (
    <div className="App">
      <h1 className="titulo">Loja Virtual de Eletrodomésticos</h1>
      <div className="container-produtos">
        {produtos.map((item, index) => (
          <CardProduto
            key={index}
            imagem={item.imagem}
            nome={item.nome}
            preco={item.preco}
            descricao={item.descricao}
          />
        ))}
      </div>
    </div>
  );
}

export default App;